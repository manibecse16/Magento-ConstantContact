<?php 
/**
 * Integrate Constant Contact
 *
 * @category   Constant Contact
 * @package    SMT_ConstantContact
 * @author     SMT
 *
 */

require_once(Mage::getBaseDir('lib') . "/ConstantContact/vendor/autoload.php");
use Ctct\ConstantContact;
use Ctct\Components\Contacts\Contact;
use Ctct\Exceptions\CtctException;

class SMT_ConstantContact_Model_Constantcontact extends Mage_Core_Model_Abstract
{
    public function _construct() {
        parent::_construct();
        $this->_init('constantcontact/constantcontact');
    }

    /*
     * Get All Email List in Constant Contact
     *
     * @return $list
     */
	public function getConstantcontactlist() {
		$cc = new ConstantContact(Mage::helper('constantcontact')->getAPIkey());
		try {
			$lists = $cc->listService->getLists(Mage::helper('constantcontact')->getAccessToken());
		} catch (CtctException $ex) {
			if (!isset($lists)) {
				$lists = null;
			}
		}
		return $lists;
	}

    /*
     * Add Email-id in Constant Contact
     *
     * @param array $data
     * @return int $statusCode
     */
	public function addConstantcontactItem($data) {
		$statusCode=array();
		$access_token = Mage::helper('constantcontact')->getAccessToken();
		$currentList = Mage::helper('constantcontact')->getCurrentList();
		$cc = new ConstantContact(Mage::helper('constantcontact')->getAPIkey());
		$response = $cc->contactService->getContacts($access_token, array("email" =>$data['email']));
		if (empty($response->results)) {
			$contact = new Contact();
			$contact->addEmail($data['email']);
			$contact->addList($currentList);
			$contact->first_name =$data['firstname'];
			$contact->last_name = $data['lastname'];
			$statusCode = $cc->contactService->addContact($access_token, $contact);
		}
		return $statusCode;
	}
}
