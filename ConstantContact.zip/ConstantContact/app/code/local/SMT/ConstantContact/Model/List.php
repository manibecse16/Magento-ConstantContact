<?php
/**
 * Integrate Constant Contact
 *
 * @category   Constant Contact
 * @package    SMT_ConstantContact
 * @author     SMT
 *
 */

class SMT_ConstantContact_Model_List extends  Mage_Core_Model_Abstract
{
	public function _construct() {
		parent::_construct();
		$this->_init('constantcontact/list');
	}

	/*
	 *
	 * Display the Email List
	 *
	 */
	public function toOptionArray() {
		$array[] = array('label' => " -- Select -- ", 'value' => "");
		$lists = Mage::getModel('constantcontact/constantcontact')->getConstantcontactlist();
		foreach($lists as $list) {
			$label = $list->name;
			$value = $list->id;				
			$array[] = array('label' => $label, 'value' => $value);
		}
		return $array;
    }
}
