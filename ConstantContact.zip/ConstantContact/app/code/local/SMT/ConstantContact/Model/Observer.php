<?php
/**
 * Integrate Constant Contact
 *
 * @category   Constant Contact
 * @package    SMT_ConstantContact
 * @author     SMT
 *
 */

class SMT_ConstantContact_Model_Observer 
{

    /**
     * Customer Create Subscribe
     *
     * @param object $observer
     * @return 
     */
	public function subscribeConstantContact($observer) {
        $customer = $observer->getEvent()->getCustomer();
		if(Mage::helper('constantcontact')->isActive()){
        if (($customer instanceof Mage_Customer_Model_Customer)) {
			if($customer->getIsSubscribed()) {
				$data = array (
							'email' => $customer->getEmail(),
							'firstname' => $customer->getFirstname(),
							'lastname' => $customer->getLastname()
						);
				Mage::getModel('constantcontact/constantcontact')->addConstantcontactItem($data);
			}
        }
		}
    }

    /**
     * Order Place Subscribe
     *
     * @param object $observer
     * @return 
     */
	public function orderSubscribeConstantContact($observer) {
		$order = $observer->getEvent()->getOrder();
		if(Mage::helper('constantcontact')->isActive()){
			$email = ($order->getCustomerId()) ? $order->getCustomerEmail() : $order->getBillingAddress()->getEmail();
			if($email) {
				$data = array (
					'email' => $email,
					'firstname' => $order->getBillingAddress()->getFirstname(),
					'lastname' => $order->getBillingAddress()->getLastname()
				);
				Mage::getModel('constantcontact/constantcontact')->addConstantcontactItem($data);
			}
		}
	}    
}