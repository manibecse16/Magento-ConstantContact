<?php
/**
 * Integrate Constant Contact
 *
 * @category   Constant Contact
 * @package    SMT_ConstantContact
 * @author     SMT
 *
 */
 
class SMT_ConstantContact_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getAPIkey() {
		return  Mage::getStoreConfig('constantcontact/settings/constant_api_key');
	}

	public function getCurrentList() {
		return  Mage::getStoreConfig('constantcontact/settings/constant_list');
	}

	public function getAccessToken() {
		return  Mage::getStoreConfig('constantcontact/settings/constant_access_token');
	}
	public function isActive() {
		return  Mage::getStoreConfig('constantcontact/settings/constant_status');
	}
}
	 